#include "licovanidvou.h"
#include "ui_licovanidvou.h"
#include "util/upravy_obrazu.h"
#include "util/pouzij_frangiho.h"
#include "licovani/multiPOC_Ai1.h"
#include "licovani/korekce_zapis.h"
#include "licovani/fazova_korelace_funkce.h"
#include "dialogy/errordialog.h"
#include "dialogy/clickimageevent.h"
#include "dialogy/frangi_detektor.h"

#include <opencv2/core.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc_c.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgcodecs/imgcodecs.hpp>
#include <opencv2/imgcodecs/imgcodecs_c.h>

#include <QFileDialog>
#include <QCheckBox>
#include <QLabel>
#include <QLineEdit>
#include <QDebug>
#include <QtGui>
#include <QPixmap>
#include <QEvent>
#include <QMouseEvent>
#include <QPointF>
#include <QSpacerItem>
#include <array>

int slider_position=0;
int alpha_slider;
cv::Mat src1;
cv::Mat src2;


static void on_trackbar( int, void* )
{
    if(slider_position == 0){cv::imshow("Kontrola_licovani",src1);}
    else {cv::imshow("Kontrola_licovani",src2);}
}

LicovaniDvou::LicovaniDvou(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LicovaniDvou)
{
    ui->setupUi(this);
    /***********************************************************************************/
    // nastavení výchozích parametrů pro lícování
    ui->oblastMaxima->setText("10");
    oblastMaxima = 10.0;
    ui->uhelRotace->setText("0.1");
    uhel = 0.1;
    ui->pocetIteraci->setText("-1");
    iterace = -1;
    ui->casovaZnacka->setChecked(false);
    ui->anomalie->setChecked(false);
    /***********************************************************************************/
    // nastavení parametrů pro frangiho detektor - buď soubor existuje, nebo neexistuje
    // a zvolí se výchozí parametry pro algoritmus
    maximum_frangi = detekovane_frangiho_maximum;
    connect(ui->anomalie,SIGNAL(stateChanged(int)),this,SLOT(zobrazKliknutelnyDialog()));
    velikost_frangi_opt(6);
    QFile soubor(QDir::currentPath()+"/"+"frangi_parametry.txt");
    //bool soubor_pritomen = false;
    if (soubor.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        //soubor_pritomen = true;
        QTextStream in(&soubor);
        int pocitadlo = 0;
        while (!in.atEnd())
        {
            QString line = in.readLine();
            inicializace_frangi_opt(line,pocitadlo);
            pocitadlo+=1;
        }
    }
    else
    {
        parametry_frangi[0] = 1;
        parametry_frangi[1] = 10;
        parametry_frangi[2] = 1;
        parametry_frangi[3] = 8.0;
        parametry_frangi[4] = 8.0;
        parametry_frangi[5] = 1;
    }
    /***********************************************************************************/
    // protože se pracuje s layouty a comboboxy, je potřeba definovat defaultní zobrazení
    // nabídky a odpovídajících widgetů
    // první v nabídce je lícování dvou snímků -> layout bude zaplněn prvky pro tuto nabídku
    QLineEdit* vybraneVideoLE = new QLineEdit();
    QPushButton* vyberVideaPB = new QPushButton();
    QLineEdit* cisloReferenceLE = new QLineEdit();
    QLineEdit* cisloPosunutehoLE = new QLineEdit();
    QSpacerItem* horizontalSpacer1 = new QSpacerItem(20,20);
    /*******/
    vybraneVideoLE->setPlaceholderText("Vybrané video");
    vybraneVideoLE->setMinimumWidth(110);
    vybraneVideoLE->setMinimumHeight(20);
    /******/
    vyberVideaPB->setText("Výběr videa");
    vyberVideaPB->setMinimumWidth(71);
    vyberVideaPB->setMinimumHeight(23);
    /******/
    cisloReferenceLE->setPlaceholderText("Ref");
    cisloReferenceLE->setMinimumWidth(31);
    cisloReferenceLE->setMinimumHeight(20);
    /******/
    cisloPosunutehoLE->setPlaceholderText("Posun");
    cisloPosunutehoLE->setMinimumWidth(41);
    cisloPosunutehoLE->setMinimumHeight(20);
    /*****/
    ui->nabidkaAnalyzy->addWidget(vybraneVideoLE,0,0);
    ui->nabidkaAnalyzy->addWidget(vyberVideaPB,0,1);
    ui->nabidkaAnalyzy->addWidget(cisloReferenceLE,0,2);
    ui->nabidkaAnalyzy->addWidget(cisloPosunutehoLE,0,3);
    ui->nabidkaAnalyzy->addItem(horizontalSpacer1,0,4);
    /*****/
    QWidget* widgetVideoPB = ui->nabidkaAnalyzy->itemAt(1)->widget();
    QWidget* widgetVideoLE = ui->nabidkaAnalyzy->itemAt(0)->widget();
    connect(widgetVideoPB,SIGNAL(clicked()),this,SLOT(vyberVideaPB_clicked()));
    /***********************************************************************************/
    /*ui->nabidkaAnalyzy->addWidget(vybraneVideoLE,0,0);
    ui->nabidkaAnalyzy->addWidget(vyberVideaPB,0,1);
    ui->nabidkaAnalyzy->addWidget(cisloReferenceLE,0,2);
    ui->nabidkaAnalyzy->addWidget(cisloPosunutehoLE,0,3);
    ui->nabidkaAnalyzy->addItem(horizontalSpacer1,0,4);*/
    /*ui->nabidkaAnalyzy->addWidget(volbaReferenceLE,0,0);
    ui->nabidkaAnalyzy->addWidget(vyberObrazekReferencePB,0,1);
    ui->nabidkaAnalyzy->addWidget(volbaPosunutehoLE,0,2);
    ui->nabidkaAnalyzy->addWidget(vyberObrazekPosunutyPB,0,3);*/
}

LicovaniDvou::~LicovaniDvou()
{
    delete ui;
}

void LicovaniDvou::velikost_frangi_opt(int velikost){
    parametry_frangi = (QVector<double>(velikost));
}

void LicovaniDvou::inicializace_frangi_opt(QString &hodnota, int &pozice)
{
    parametry_frangi[pozice] = hodnota.toDouble();
}
void LicovaniDvou::on_comboBox_activated(int index)
{
    qDebug()<<"Index Comboboxu: "<<index;
    if (index == 0)
    {
        clearLayout(ui->nabidkaAnalyzy);
        QLineEdit* vybraneVideoLE = new QLineEdit(this);
        QPushButton* vyberVideaPB = new QPushButton(this);
        QLineEdit* cisloReferenceLE = new QLineEdit(this);
        QLineEdit* cisloPosunutehoLE = new QLineEdit(this);
        QSpacerItem* horizontalSpacer1 = new QSpacerItem(20,20);
        /*******/
        vybraneVideoLE->setPlaceholderText("Vybrané video");
        vybraneVideoLE->setMinimumWidth(110);
        vybraneVideoLE->setMinimumHeight(20);
        /******/
        vyberVideaPB->setText("Výběr videa");
        vyberVideaPB->setMinimumWidth(71);
        vyberVideaPB->setMinimumHeight(23);
        /******/
        cisloReferenceLE->setPlaceholderText("Ref");
        cisloReferenceLE->setMinimumWidth(31);
        cisloReferenceLE->setMinimumHeight(20);
        /******/
        cisloPosunutehoLE->setPlaceholderText("Posun");
        cisloPosunutehoLE->setMinimumWidth(41);
        cisloPosunutehoLE->setMinimumHeight(20);
        /**************************************************/
        ui->nabidkaAnalyzy->addWidget(vybraneVideoLE,0,0);
        ui->nabidkaAnalyzy->addWidget(vyberVideaPB,0,1);
        ui->nabidkaAnalyzy->addWidget(cisloReferenceLE,0,2);
        ui->nabidkaAnalyzy->addWidget(cisloPosunutehoLE,0,3);
        ui->nabidkaAnalyzy->addItem(horizontalSpacer1,0,4);
        /**************************************************/
        QPushButton* widgetVideoPB = qobject_cast<QPushButton *>(ui->nabidkaAnalyzy->itemAt(1)->widget());
        //QWidget *widget = qobject_cast<QWidget *>(obj);
        QLineEdit* widgetVideoLE = qobject_cast<QLineEdit *>(ui->nabidkaAnalyzy->itemAt(0)->widget());
        connect(widgetVideoPB,SIGNAL(clicked()),this,SLOT(vyberVideaPB_clicked(&widgetVideoLE)));
    }
    else if (index == 1)
    {
        clearLayout(ui->nabidkaAnalyzy);
        QSpacerItem* horizontalSpacer2 = new QSpacerItem(5,20);
        QLineEdit* volbaReferenceLE = new QLineEdit();
        QLineEdit* volbaPosunutehoLE = new QLineEdit();
        QPushButton* vyberObrazekReferencePB = new QPushButton();
        QPushButton* vyberObrazekPosunutyPB = new QPushButton();
        /*****/
        volbaReferenceLE->setMinimumWidth(20);
        volbaReferenceLE->setMinimumHeight(20);
        volbaReferenceLE->setPlaceholderText("Ref");
        /*****/
        volbaPosunutehoLE->setMinimumWidth(20);
        volbaPosunutehoLE->setMinimumHeight(20);
        volbaPosunutehoLE->setPlaceholderText("Pos");
        /*****/
        vyberObrazekReferencePB->setText("Výběr reference");
        vyberObrazekReferencePB->setMinimumWidth(90);
        vyberObrazekReferencePB->setMinimumHeight(23);
        /*****/
        vyberObrazekPosunutyPB->setText("Výběr posunutého");
        vyberObrazekPosunutyPB->setMinimumWidth(90);
        vyberObrazekPosunutyPB->setMinimumHeight(23);
        /***************************************************/
        ui->nabidkaAnalyzy->addWidget(volbaReferenceLE,0,0);
        ui->nabidkaAnalyzy->addWidget(vyberObrazekReferencePB,0,1);        
        ui->nabidkaAnalyzy->addWidget(volbaPosunutehoLE,0,2);
        ui->nabidkaAnalyzy->addWidget(vyberObrazekPosunutyPB,0,3);
        ui->nabidkaAnalyzy->addItem(horizontalSpacer2,0,4);
    }
}

void LicovaniDvou::clearLayout(QGridLayout *layout)
{
    int pocetSLoupcu = layout->columnCount();
    int pocetRadku = layout->rowCount();
    qDebug()<<"pocetSLoupcu: "<<pocetSLoupcu<<" pocetRadku: "<<pocetRadku;
    for (int a = 1; a <= pocetRadku; a++)
    {
        for (int b = 1; b <= pocetSLoupcu; b++)
        {
            QWidget* widget = layout->itemAtPosition(a-1,b-1)->widget();
            layout->removeWidget(widget);
            delete widget;
        }
    }
}
void LicovaniDvou::vyberVideaPB_clicked(QLineEdit *LE)
{
    QString videoProFrangiFiltr = QFileDialog::getOpenFileName(this,
                                                               "Vyberte snímek pro Frangiho filtr", "","*.avi;;Všechny soubory (*)");
    int lastindexSlash = videoProFrangiFiltr.lastIndexOf("/");
    int lastIndexComma = videoProFrangiFiltr.length() - videoProFrangiFiltr.lastIndexOf(".");
    QString vybrana_slozka = videoProFrangiFiltr.left(lastindexSlash);
    QString vybrany_soubor = videoProFrangiFiltr.mid(lastindexSlash+1,
                                                     (videoProFrangiFiltr.length()-lastindexSlash-lastIndexComma-1));
    QString koncovka = videoProFrangiFiltr.right(lastIndexComma-1);
    rozborVybranehoSouboru.push_back(vybrana_slozka);
    rozborVybranehoSouboru.push_back(vybrany_soubor);
    rozborVybranehoSouboru.push_back(koncovka);
    QLineEdit cislo_snimku;
    vybrane_video = rozborVybranehoSouboru[1];
    LE->setText(rozborVybranehoSouboru[1]);
    QString cesta_k_souboru = rozborVybranehoSouboru[0]+"/"+rozborVybranehoSouboru[1]+"."+rozborVybranehoSouboru[2];
    cap = cv::VideoCapture(cesta_k_souboru.toLocal8Bit().constData());
    if (!cap.isOpened())
    {
        qDebug()<<"video nelze otevrit pro potreby zpracovani";
        spravnostVidea = false;
    }
    else
    {
        spravnostVidea = true;
    }
}

void LicovaniDvou::on_vybraneVideoLE_textChanged(const QString &text)
{
    QString kompletni_cesta = rozborVybranehoSouboru[0]+"/"+text+"."+rozborVybranehoSouboru[2];
    cap = cv::VideoCapture(kompletni_cesta.toLocal8Bit().constData());
    if (!cap.isOpened())
    {
        ui->vybraneVideoLE->setStyleSheet("QLineEdit#vybraneVideoLE{color: #FF0000}");
        //qDebug()<<"video nelze otevrit pro potreby zpracovani";
        spravnostVidea = false;
    }
    else
    {
        ui->vybraneVideoLE->setStyleSheet("QLineEdit#vybraneVideoLE{color: #00FF00}");
        spravnostVidea = true;
        rozborVybranehoSouboru[1] = text;
    }
}

void LicovaniDvou::on_cisloReference_textChanged(const QString &arg1)
{
    int pocet_snimku_videa = int(cap.get(CV_CAP_PROP_FRAME_COUNT));
    int zadane_cislo = arg1.toInt();
    if (zadane_cislo < 0 || zadane_cislo > pocet_snimku_videa)
    {
        ui->cisloReference->setStyleSheet("QLineEdit#cisloReference{color: #FF0000}");
        //qDebug()<<"Referencni snimek nelze ve videu dohledat";
        spravnostReference = false;
        cisloReference = -1;
    }
    else
    {
        ui->cisloReference->setStyleSheet("QLineEdit#cisloReference{color: #00FF00}");
        spravnostReference = true;
        cisloReference = zadane_cislo;
    }
}

void LicovaniDvou::on_cisloPosunuteho_textChanged(const QString &arg1)
{
    int pocet_snimku_videa = int(cap.get(CV_CAP_PROP_FRAME_COUNT));
    int zadane_cislo = arg1.toInt();
    if (zadane_cislo < 0 || zadane_cislo > pocet_snimku_videa)
    {
        ui->cisloPosunuteho->setStyleSheet("QLineEdit#cisloPosunuteho{color: #FF0000}");
        //qDebug()<<"Referencni snimek nelze ve videu dohledat";
        spravnostPosunuteho = false;
        cisloPosunuteho = -1;
    }
    else
    {
        ui->cisloPosunuteho->setStyleSheet("QLineEdit#cisloPosunuteho{color: #00FF00}");
        spravnostPosunuteho = true;
        cisloPosunuteho = zadane_cislo;
    }
}

void LicovaniDvou::on_oblastMaxima_textChanged(const QString &arg1)
{
    double oblast_maxima_minimum = 0.0;
    double oblast_maxima_maximum = 20.0;
    double zadane_cislo = arg1.toDouble();
    if (zadane_cislo < oblast_maxima_minimum || zadane_cislo > oblast_maxima_maximum)
    {
        ui->oblastMaxima->setStyleSheet("QLineEdit#oblastMaxima{color: #FF0000}");
        spravnostOblasti = false;
        oblastMaxima = -1;
    }
    else
    {
        ui->oblastMaxima->setStyleSheet("QLineEdit#oblastMaxima{color: #00FF00}");
        spravnostOblasti = true;
        oblastMaxima = zadane_cislo;
    }
}

void LicovaniDvou::on_uhelRotace_textChanged(const QString &arg1)
{
    double oblast_maxima_minimum = 0.0;
    double oblast_maxima_maximum = 0.5;
    double zadane_cislo = arg1.toDouble();
    if (zadane_cislo < oblast_maxima_minimum || zadane_cislo > oblast_maxima_maximum)
    {
        ui->uhelRotace->setStyleSheet("QLineEdit#uhelRotace{color: #FF0000}");
        spravnostUhlu = false;
        uhel = 0.1;
    }
    else
    {
        ui->uhelRotace->setStyleSheet("QLineEdit#uhelRotace{color: #00FF00}");
        spravnostUhlu = true;
        uhel = zadane_cislo;
    }
}

void LicovaniDvou::on_pocetIteraci_textChanged(const QString &arg1)
{
    int zadane_cislo = arg1.toInt();
    if (zadane_cislo < 0 && zadane_cislo != -1)
    {
        ui->pocetIteraci->setStyleSheet("QLineEdit#pocetIteraci{color: #FF0000}");
        spravnostIteraci = false;

        iterace = -1;
    }
    if (zadane_cislo == -1 || zadane_cislo > 1)
    {
        ui->pocetIteraci->setStyleSheet("QLineEdit#pocetIteraci{color: #00FF00}");
        spravnostIteraci = true;
        if (zadane_cislo == -1)
        {
            iterace = -1;
        }
        else
        {
            iterace = zadane_cislo;
        }
    }
}

void LicovaniDvou::on_slicujDvaSnimky_clicked()
{
    //this->setWindowState((windowState() & ~Qt::WindowMinimized) | Qt::WindowActive);
    //MainWindow* mojeplikace = new MainWindow();
    //mojeplikace->showMinimized();
    if (spravnostVidea == false || spravnostReference == false || spravnostPosunuteho == false
            || spravnostOblasti == false || spravnostUhlu == false || spravnostIteraci == false)
    {
        ErrorDialog* errordialog = new ErrorDialog;
        errordialog->setModal(true);
        errordialog->exec();
    }
    else
    {
        qDebug()<<parametry_frangi;
        qDebug()<<parametry_frangi.length();
        QString cesta_k_souboru = rozborVybranehoSouboru[0]+"/"+rozborVybranehoSouboru[1]+"."+rozborVybranehoSouboru[2];
        cap = cv::VideoCapture(cesta_k_souboru.toLocal8Bit().constData());
        cap.set(CV_CAP_PROP_POS_FRAMES,double(cisloReference));
        cv::Mat referencni_snimek,posunuty;
        cap.read(referencni_snimek);
        kontrola_typu_snimku_8C3(referencni_snimek);
        qDebug()<<"reference má "<<referencni_snimek.channels()<<" kanálů a typu "<<referencni_snimek.type();
        cap.set(CV_CAP_PROP_POS_FRAMES,double(cisloPosunuteho));
        cap.read(posunuty);
        kontrola_typu_snimku_8C3(posunuty);

        cv::Point3d pt_temp(0.0,0.0,0.0);
        cv::Rect vyrez_anomalie(0,0,0,0);
        double sirka_framu = cap.get(CV_CAP_PROP_FRAME_WIDTH);
        ziskane_hranice_anomalie = oznacena_hranice_anomalie;
        qDebug()<<"MousePressEvent označil: "<<ziskane_hranice_anomalie.x<<" "<<ziskane_hranice_anomalie.y;
        if (ziskane_hranice_anomalie.x != 0.0f)
        {
            if (ziskane_hranice_anomalie.x < float(sirka_framu/2))
            {
                vyrez_anomalie.x = 0;
                vyrez_anomalie.y = int(ziskane_hranice_anomalie.x);
                vyrez_anomalie.width = int(sirka_framu-int(ziskane_hranice_anomalie.x)-1);
                vyrez_anomalie.height = int(cap.get(CV_CAP_PROP_FRAME_HEIGHT));
            }
            if (ziskane_hranice_anomalie.x > float(sirka_framu/2))
            {
                vyrez_anomalie.x = 0;
                vyrez_anomalie.y = 0;
                vyrez_anomalie.width = int(ziskane_hranice_anomalie.x);
                vyrez_anomalie.height = int(cap.get(CV_CAP_PROP_FRAME_HEIGHT));
            }
        }
        bool nutnost_zmenit_velikost = false;
        int rows = referencni_snimek.rows;
        int cols = referencni_snimek.cols;
        int radek_od = int(round(maximum_frangi.y-0.8*maximum_frangi.y));
        int radek_do = int(round(maximum_frangi.y+0.8*(rows - maximum_frangi.y)));
        int sloupec_od = 0;
        int sloupec_do = 0;
        /******************************************/
        if (ui->casovaZnacka->isChecked()){pritomnost_casove_znacky = true;}
        else {pritomnost_casove_znacky = false;}
        /******************************************/
        if (ui->anomalie->isChecked()){pritomnost_svetelne_anomalie = true;}
        else{pritomnost_svetelne_anomalie = false;}
        /******************************************/
        if (pritomnost_svetelne_anomalie == true && int(ziskane_hranice_anomalie.y)<(cols/2))
        {
            sloupec_od = int(ziskane_hranice_anomalie.y);
            nutnost_zmenit_velikost = true;
        }
        else {sloupec_od = round(maximum_frangi.x-0.8*(maximum_frangi.x));}
        /******************************************/
        if (pritomnost_svetelne_anomalie == true && int(ziskane_hranice_anomalie.y)>(cols/2))
        {
            sloupec_do = int(ziskane_hranice_anomalie.y);
            nutnost_zmenit_velikost = true;
        }
        else {sloupec_do = round(maximum_frangi.x+0.9*(cols - maximum_frangi.x));}
        int vyrez_sirka = sloupec_do-sloupec_od;
        int vyrez_vyska = radek_do - radek_od;
        cv::Rect vyrez_korelace_extra(0,0,0,0);
        cv::Rect vyrez_korelace_standard(0,0,0,0);
        cv::Mat obraz;
        /******************************************/
        if ((vyrez_vyska>480 || vyrez_sirka>640)|| nutnost_zmenit_velikost == true)
        {
            vyrez_korelace_extra.x = sloupec_od;
            vyrez_korelace_extra.y = radek_od;
            vyrez_korelace_extra.width = vyrez_sirka;
            vyrez_korelace_extra.height = vyrez_vyska;
            /*****************************************/
            referencni_snimek(vyrez_korelace_extra).copyTo(obraz);            
            /*****************************************/
            maximum_frangi = frangi_analyza(obraz,1,1,0,"",1,false,pt_temp,parametry_frangi);
            rows = obraz.rows;
            cols = obraz.cols;
            radek_od = round(maximum_frangi.y-0.9*maximum_frangi.y);
            radek_do = round(maximum_frangi.y+0.9*(rows - maximum_frangi.y));
            sloupec_od = round(maximum_frangi.x-0.9*(maximum_frangi.x));
            sloupec_do = round(maximum_frangi.x+0.9*(cols - maximum_frangi.x));
            vyrez_sirka = sloupec_do-sloupec_od;
            vyrez_vyska = radek_do - radek_od;
            vyrez_korelace_standard.x = sloupec_od;
            vyrez_korelace_standard.y = radek_od;
            vyrez_korelace_standard.width = vyrez_sirka;
            vyrez_korelace_standard.height = vyrez_vyska;
            zmena_meritka = true;
        }
        else
        {
            vyrez_korelace_standard.x = round(maximum_frangi.x-0.9*(maximum_frangi.x));
            vyrez_korelace_standard.y = round(maximum_frangi.y-0.9*maximum_frangi.y);;
            radek_do = round(maximum_frangi.y+0.9*(rows - maximum_frangi.y));
            sloupec_do = round(maximum_frangi.x+0.9*(cols - maximum_frangi.x));
            vyrez_korelace_standard.width = sloupec_do-vyrez_korelace_standard.x;
            vyrez_korelace_standard.height = radek_do - vyrez_korelace_standard.y;
            referencni_snimek.copyTo(obraz);            
            //obraz_temp.release();
        }
        /********************************************/
        cv::Mat obraz_32f,obraz_vyrez;
        obraz.copyTo(obraz_32f);
        //posunuty.copyTo(posunuty_32f);
        kontrola_typu_snimku_32C1(obraz_32f);
        //kontrola_typu_snimku_32C1(posunuty_32f);
        qDebug()<<"Obraz "<<obraz.channels();
        qDebug()<<"Posunuty"<<posunuty.channels();
        qDebug()<<"Obraz 32"<<obraz_32f.channels();
        //qDebug()<<"Posunuty 320"<<posunuty_32f.channels();
        /********************************************/
        obraz_32f(vyrez_korelace_standard).copyTo(obraz_vyrez);
        cv::Point3d maximum_frangi_reverse = frangi_analyza(obraz,2,2,0,"",1,false,pt_temp,parametry_frangi);
        qDebug()<<"Maximum frangi reverse "<<maximum_frangi_reverse.x<<" "<<maximum_frangi_reverse.y;
        /********************************************/
        /// Začátek
        cv::Mat mezivysledek = cv::Mat::zeros(obraz.size(), CV_32FC3);
        cv::Point3d pt3;
        double uhel = 0;
        double celkovy_uhel = 0;
        int uspech_slicovani = kompletni_slicovani(cap,
                                    referencni_snimek,
                                    cisloPosunuteho,
                                    iterace,
                                    oblastMaxima,
                                    uhel,
                                    vyrez_korelace_extra,
                                    vyrez_korelace_standard,
                                    zmena_meritka,
                                    mezivysledek,
                                    pt3,
                                    celkovy_uhel);
        /// Konec
        if (uspech_slicovani==0)
            qDebug()<<"Licovani skoncilo chybou";
        else
        {
            cv::Mat korekce = eventualni_korekce_translace(mezivysledek,obraz,vyrez_korelace_standard,pt3,oblastMaxima);
            qDebug()<<"Mezivýsledek "<<mezivysledek.channels()<<" "<<mezivysledek.type();
            qDebug()<<pt3.x<<" "<<pt3.y;
            cv::Point3d pt5 = fk_translace_hann(obraz,mezivysledek,oblastMaxima);
            qDebug()<<pt5.x<<" "<<pt5.y;
            double sigma_gauss = 1/(std::sqrt(2*CV_PI)*pt5.z);
            double FWHM = 2*std::sqrt(2*std::log(2)) * sigma_gauss;
            qDebug()<<"FWHM: "<<FWHM;
            cv::Point3d pt6 = fk_translace(obraz,korekce,oblastMaxima);
            qDebug()<<pt6.x<<" "<<pt6.y;
            cv::Point3d souradnice_slicovany_frangi_reverse = frangi_analyza(mezivysledek,2,2,0,"",2,false,pt3,parametry_frangi);
            cv::Point3d souradnice_slicovany_frangi = frangi_analyza(mezivysledek,1,1,0,"",2,false,pt3,parametry_frangi);
            double yydef = maximum_frangi_reverse.x - souradnice_slicovany_frangi_reverse.x;
            double xxdef = maximum_frangi_reverse.y - souradnice_slicovany_frangi_reverse.y;
            cv::Point3d vysledne_posunuti;
            vysledne_posunuti.y = pt3.y - yydef;
            vysledne_posunuti.x = pt3.x - xxdef;
            vysledne_posunuti.z = 0;
            cv::Mat posunuty_temp2 = translace_snimku(posunuty,vysledne_posunuti,rows,cols);
            cv::Mat finalni_licovani = rotace_snimku(posunuty_temp2,uhel);
            cv::Mat finalni_licovani_32f,finalni_licovani_32f_vyrez;
            finalni_licovani.copyTo(finalni_licovani_32f);
            kontrola_typu_snimku_32C1(finalni_licovani_32f);
            finalni_licovani_32f(vyrez_korelace_standard).copyTo(finalni_licovani_32f_vyrez);
            qDebug()<<"Licovani dokonceno";
            src1 = obraz;
            src2 = mezivysledek;
            kontrola_typu_snimku_8C3(src1);
            kontrola_typu_snimku_8C3(src2);
            alpha_slider = 0;
            cv::namedWindow("Kontrola_licovani", CV_WINDOW_AUTOSIZE); // Create Window
            cv::createTrackbar("Vybrany snimek","Kontrola_licovani",&slider_position,2,on_trackbar);
            on_trackbar( alpha_slider, 0 );
            /*for(;;)
            {
                if(slider_position == 1)
                    imshow( "Kontrola_licovani", src1);
                else
                    imshow( "Kontrola_licovani", src2);
                on_trackbar( alpha_slider, 0 );
            }*/
        }
    }
}

void LicovaniDvou::zobrazKliknutelnyDialog()
{
    if (ui->anomalie->isChecked())
    {
        QString kompletni_cesta = rozborVybranehoSouboru[0]+"/"+rozborVybranehoSouboru[1]+"."+rozborVybranehoSouboru[2];
        ClickImageEvent* vyznac_anomalii = new ClickImageEvent(kompletni_cesta,cisloReference);
        vyznac_anomalii->setModal(true);
        vyznac_anomalii->exec();
        /*QObject::connect(vyznac_anomalii,SIGNAL(SendClickCoordinates(QPointF)),
                         this,SLOT(GetClickCoordinates(QPointF)));*/
        //connect(vyznac_anomalii, vyznac_anomalii->SendClickCoordinates, (=)[const auto &myString] {ui->label->setText(myString);});
    }
}

/*void LicovaniDvou::GetClickCoordinates(const QPointF hranice_anomalie)
{
    oznacena_hranice_anomalie.x = float(hranice_anomalie.x());
    oznacena_hranice_anomalie.y = float(hranice_anomalie.y());
    qDebug()<<"GetClickCoordinates: "<<oznacena_hranice_anomalie.x<<" "<<oznacena_hranice_anomalie.y;
}*/


