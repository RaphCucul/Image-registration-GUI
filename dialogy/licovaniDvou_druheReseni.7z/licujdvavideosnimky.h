#ifndef LICUJDVAVIDEOSNIMKY_H
#define LICUJDVAVIDEOSNIMKY_H

#include <QWidget>
#include <opencv2/opencv.hpp>

namespace Ui {
class licujDvaVideosnimky;
}

class licujDvaVideosnimky : public QWidget
{
    Q_OBJECT

public:
    explicit licujDvaVideosnimky(QWidget *parent = nullptr);
    ~licujDvaVideosnimky();

private slots:
    void on_vybraneVideoLE_textChanged(const QString &arg1);

    void on_vyberVideoPB_clicked();

    void on_cisloReferenceLE_textChanged(const QString &arg1);

    void on_cisloPosunutehoLE_textChanged(const QString &arg1);

private:
    Ui::licujDvaVideosnimky *ui;
    QVector<QString> rozborVybranehoSouboru;
    cv::VideoCapture cap;
    int cisloReference = -1;
    int cisloPosunuteho = -1;
    /***************************************/
    bool spravnostVidea = false;
    bool spravnostReference = false;
    bool spravnostPosunuteho = false;
};

#endif // LICUJDVAVIDEOSNIMKY_H
