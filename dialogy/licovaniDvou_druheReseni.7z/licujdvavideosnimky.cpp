#include "licujdvavideosnimky.h"
#include "ui_licujdvavideosnimky.h"

#include <opencv2/core.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc_c.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgcodecs/imgcodecs.hpp>
#include <opencv2/imgcodecs/imgcodecs_c.h>

#include <QLineEdit>
#include <QDebug>
#include <QtGui>
#include <QFileDialog>

licujDvaVideosnimky::licujDvaVideosnimky(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::licujDvaVideosnimky)
{
    ui->setupUi(this);
}

licujDvaVideosnimky::~licujDvaVideosnimky()
{
    delete ui;
}

void licujDvaVideosnimky::on_vybraneVideoLE_textChanged(const QString &arg1)
{
    QString kompletni_cesta = rozborVybranehoSouboru[0]+"/"+arg1+"."+rozborVybranehoSouboru[2];
    cap = cv::VideoCapture(kompletni_cesta.toLocal8Bit().constData());
    if (!cap.isOpened())
    {
        ui->vybraneVideoLE->setStyleSheet("QLineEdit#vybraneVideoLE{color: #FF0000}");
        //qDebug()<<"video nelze otevrit pro potreby zpracovani";
        spravnostVidea = false;
    }
    else
    {
        ui->vybraneVideoLE->setStyleSheet("QLineEdit#vybraneVideoLE{color: #00FF00}");
        spravnostVidea = true;
        rozborVybranehoSouboru[1] = arg1;
    }
}

void licujDvaVideosnimky::on_vyberVideoPB_clicked()
{
    QString videoProFrangiFiltr = QFileDialog::getOpenFileName(this,
                                                               "Vyberte snímek pro Frangiho filtr", "","*.avi;;Všechny soubory (*)");
    int lastindexSlash = videoProFrangiFiltr.lastIndexOf("/");
    int lastIndexComma = videoProFrangiFiltr.length() - videoProFrangiFiltr.lastIndexOf(".");
    QString vybrana_slozka = videoProFrangiFiltr.left(lastindexSlash);
    QString vybrany_soubor = videoProFrangiFiltr.mid(lastindexSlash+1,
                                                     (videoProFrangiFiltr.length()-lastindexSlash-lastIndexComma-1));
    QString koncovka = videoProFrangiFiltr.right(lastIndexComma-1);
    rozborVybranehoSouboru.push_back(vybrana_slozka);
    rozborVybranehoSouboru.push_back(vybrany_soubor);
    rozborVybranehoSouboru.push_back(koncovka);
    QLineEdit cislo_snimku;
    ui->vybraneVideoLE->setText(rozborVybranehoSouboru[1]);
    QString cesta_k_souboru = rozborVybranehoSouboru[0]+"/"+rozborVybranehoSouboru[1]+"."+rozborVybranehoSouboru[2];
    cap = cv::VideoCapture(cesta_k_souboru.toLocal8Bit().constData());
    if (!cap.isOpened())
    {
        qDebug()<<"video nelze otevrit pro potreby zpracovani";
        spravnostVidea = false;
    }
    else
    {
        spravnostVidea = true;
    }
}

void licujDvaVideosnimky::on_cisloReferenceLE_textChanged(const QString &arg1)
{
    int pocet_snimku_videa = int(cap.get(CV_CAP_PROP_FRAME_COUNT));
    int zadane_cislo = arg1.toInt();
    if (zadane_cislo < 0 || zadane_cislo > pocet_snimku_videa)
    {
        ui->cisloReferenceLE->setStyleSheet("QLineEdit#cisloReference{color: #FF0000}");
        //qDebug()<<"Referencni snimek nelze ve videu dohledat";
        spravnostReference = false;
        cisloReference = -1;
    }
    else
    {
        ui->cisloReferenceLE->setStyleSheet("QLineEdit#cisloReference{color: #00FF00}");
        spravnostReference = true;
        cisloReference = zadane_cislo;
    }
}

void licujDvaVideosnimky::on_cisloPosunutehoLE_textChanged(const QString &arg1)
{
    int pocet_snimku_videa = int(cap.get(CV_CAP_PROP_FRAME_COUNT));
    int zadane_cislo = arg1.toInt();
    if (zadane_cislo < 0 || zadane_cislo > pocet_snimku_videa)
    {
        ui->cisloPosunutehoLE->setStyleSheet("QLineEdit#cisloPosunuteho{color: #FF0000}");
        //qDebug()<<"Referencni snimek nelze ve videu dohledat";
        spravnostPosunuteho = false;
        cisloPosunuteho = -1;
    }
    else
    {
        ui->cisloPosunutehoLE->setStyleSheet("QLineEdit#cisloPosunuteho{color: #00FF00}");
        spravnostPosunuteho = true;
        cisloPosunuteho = zadane_cislo;
    }
}
